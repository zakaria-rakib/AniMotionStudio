# AniMotion Studio — বাংলা চালানোর নির্দেশনা

**বর্তমান Source Version: 0.4.1 (Phase 1–4-এর source code)**

এটি Android Studio-এর সম্পূর্ণ source project। এটি সরাসরি install করার APK নয়। নিজের কম্পিউটারে Android Studio দিয়ে build করে APK তৈরি করতে হবে।

## ১. এখন পর্যন্ত কী কী যোগ হয়েছে?

### Phase 1 — Basic Animation

- নতুন Project তৈরি, পুরোনো Project খোলা ও Continue করা।
- Brush এবং Eraser দিয়ে আঁকা।
- Raster Layer যোগ, নির্বাচন, Hide/Show, Lock/Unlock, Opacity, Reorder ও Delete।
- Frame যোগ, Duplicate, Delete এবং নির্বাচন।
- Onion Skin, Play/Pause এবং FPS পরিবর্তন।
- Undo/Redo এবং Auto Save।

### Phase 2 — Vector Drawing

- Raster ও Vector Layer একই Project-এ ব্যবহার।
- Pen Tool দিয়ে Point-to-point path আঁকা।
- Cubic Bezier Curve এবং Anchor Handle তৈরি ও Edit।
- Anchor Point সরানো, Delete এবং Smooth/Corner করা।
- Vector Path Move, Scale, Rotate, Stroke Color/Width ও Fill পরিবর্তন।
- Vector drawing editable অবস্থায় Project-এ Save হয়।

### Phase 3 — Advanced Animation

- Camera Position, Zoom, Rotate এবং Camera Keyframe।
- এক Camera Keyframe থেকে অন্য Keyframe-এ interpolation।
- Vector Object-এর Position, Scale, Rotation ও Opacity Keyframe।
- Vector Object Tween Animation।
- Vector Path-এর Local Asset Library: Save, Insert ও Delete।
- একই Layer ID সব Frame-এ রাখা হয়, কিন্তু প্রত্যেক Frame-এ আলাদা artwork থাকে।

### Phase 4 — Shading, Audio ও Export

- Shadow Brush এবং Light Brush।
- Stroke Opacity ও Softness।
- Android file picker থেকে Audio Track যোগ করা।
- Editor-এর Play চালালে audio loop হয়; Pause করলে বন্ধ হয়।
- সব Frame-এর PNG এক ZIP ফাইলে Export।
- Animated GIF Export।
- Android-এর hardware encoder ব্যবহার করে silent MP4 Export (device support প্রয়োজন)।

## ২. যা এখনো পুরোপুরি তৈরি হয়নি

- MP4 Export-এর hardware encoder এখানে বাস্তব Android ফোনে পরীক্ষা করা হয়নি। MP4-তে বর্তমানে audio যুক্ত হয় না।
- Audio trim, waveform এবং frame অনুযায়ী sync করার UI নেই।
- GIF-এ 256 colour palette ব্যবহার হয়; তাই কিছু gradient/shading-এর রং কমে যেতে পারে।
- Stylus tilt এবং প্রতিটি point অনুযায়ী আলাদা brush width এখনো সম্পূর্ণ করা হয়নি।
- Canvas দুই আঙুল দিয়ে Zoom/Pan, Raster Image Import, SVG Import/Export, Fill Bucket, Lasso, Shape Tools, Layer Group, Blend Mode ইত্যাদি পরবর্তী উন্নয়নের কাজ।
- Asset Library-তে আপাতত Vector Path রাখা যায়; Raster asset/animated symbol clip এখনো নেই।

## ৩. কী কী লাগবে?

- Windows / macOS / Linux কম্পিউটার
- Android Studio (AGP 9.1.1 সমর্থন করে এমন)
- JDK 17
- Android SDK Platform 37
- Android SDK Build-Tools 36.0.0
- প্রথমবার Gradle ও dependency download করার জন্য Internet

## ৪. Android Studio-তে Project খোলা

1. ZIP ফাইল Extract করো।
2. Android Studio চালু করো।
3. **Open** চাপো।
4. `AniMotionStudio` folder নির্বাচন করো—যে folder-এর মধ্যে `settings.gradle.kts` আছে।
5. Gradle Sync সম্পন্ন হতে দাও।
6. SDK Manager থেকে Platform 37 এবং Build-Tools 36.0.0 install করো, যদি আগে না থাকে।

## ৫. APK তৈরি করা

Android Studio menu থেকে:

**Build → Build Bundle(s) / APK(s) → Build APK(s)**

Build সফল হলে APK পাওয়া যাবে:

`app/build/outputs/apk/debug/app-debug.apk`

Windows CMD থেকেও চালানো যাবে:

`gradlew.bat :app:assembleDebug`

Mac/Linux Terminal:

`./gradlew :app:assembleDebug`

## ৬. GitHub দিয়ে APK Build করার বিকল্প

Project-এর মধ্যে `.github/workflows/android-build.yml` ফাইল আছে। Project GitHub-এ push করে Actions থেকে **Build AniMotion Studio APK** চালালে GitHub Actions debug APK build করে Artifact হিসেবে upload করার চেষ্টা করবে।

## ৭. Validation ও APK সম্পর্কে সত্য তথ্য

এই workspace-এ:

- Kotlin Model ও Vector Geometry compile হয়েছে।
- Project JSON code minimal compile stub দিয়ে type-check হয়েছে।
- Exporter code Android API stub দিয়ে type-check হয়েছে।
- GIF LZW encoder-এর output Pillow দিয়ে decode করে পরীক্ষা করা হয়েছে।
- AndroidManifest XML parse হয়েছে।

কিন্তু এখানে Android SDK/`android.jar` নেই, Gradle distribution আগে থেকে নেই এবং `services.gradle.org`-এ DNS/network connection ব্যর্থ হয়েছে। তাই এই workspace থেকে পূর্ণ Android Gradle Build, APK তৈরি অথবা বাস্তব ফোনে পরীক্ষা করা সম্ভব হয়নি।

**গুরুত্বপূর্ণ:** ZIP-টি Source Project; Install করার APK নয়।

## ৮. Project File

`.animotion` Project File-এর বর্তমান format version 4। এতে Raster/Vector Layer, Frame, Brush Stroke, Stroke Opacity/Softness, Bezier Anchor/Handle, Camera Keyframe, Object Keyframe, Vector Asset এবং Audio URI সংরক্ষিত হয়। Version 1–3-এর পুরোনো Project-ও Open করার ব্যবস্থা রাখা হয়েছে।
