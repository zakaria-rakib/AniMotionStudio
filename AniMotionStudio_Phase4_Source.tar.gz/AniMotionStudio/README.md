# AniMotion Studio — Android 2D Animation Studio

**Current source milestone: v0.4.1 (Phases 1–4)**

AniMotion Studio is a native Android/Kotlin project that combines frame-by-frame raster animation with editable vector paths, camera keyframes, reusable vector assets, and basic animation rendering. It is an early, evolving project—not yet a complete replacement for FlipaClip or Adobe Animate.

## Implemented in source

### Phase 1 — Raster animation MVP

- Dark home screen, create/continue/open project.
- Finger drawing with smoothed strokes, brush and eraser.
- Raster layers, hide/show, lock/unlock, opacity, reorder and delete.
- Frame add, duplicate, delete and frame selection.
- Onion skin and playback with FPS presets.
- Undo/redo and local autosave.
- Editable `.animotion` JSON project save/open.

### Phase 2 — Vector drawing engine

- Raster and Vector layer types can exist in the same frame.
- Pen Tool: tap to add anchors; drag to create cubic Bezier handles.
- Open paths and closed/fillable shapes.
- Node Tool: select and move anchors, edit incoming/outgoing handles.
- Smooth/Corner conversion, delete anchor and delete path.
- Vector object move, scale, rotation and opacity.
- Vector stroke width, color and fill controls.
- Vector data stays editable in the project; it is not flattened to a bitmap.

### Phase 3 — Animation and reusable assets

- Camera position, zoom and rotation controls with camera keyframes.
- Camera interpolation between keyframes.
- Vector object position, scale, rotation and opacity keyframes.
- Interpolated vector-object tweening in the editor and exported frames.
- Local Asset Library for saving, reusing, inserting and deleting vector path assets.
- Stable layer identity across frames. New raster/vector layers are added to every frame; each frame stores its own artwork for that layer.
- Layer visibility, lock, opacity and ordering are shared across the animation timeline.
- Older project versions (v1–v3) are accepted and layer IDs are normalized during import.
- Project and local asset-library writes use Android AtomicFile for safer recovery after interrupted writes.

### Phase 4 — Shading, audio and rendering

- Shadow and Light drawing tools on Raster layers.
- Per-stroke opacity and softness values are saved in the project.
- Stylus pressure samples are stored in the stroke model; rendering currently uses an average pressure for stroke width rather than full per-point variable-width strokes.
- Soft shading preview in the editor; exported frames use a blur mask for a softer edge.
- Attach an audio file through Android's document picker. Audio loops while the editor Play control is active and stops on Pause.
- Export a ZIP containing one full-resolution PNG per frame, with camera/object keyframes applied.
- Export an animated GIF using a built-in GIF89a encoder and a 256-colour 3-3-2 palette.
- Export a silent H.264 MP4 using Android MediaCodec and MediaMuxer when the device exposes a supported YUV420 encoder input format. Temporary render files are deleted on success or failure.

## Known limitations — not yet implemented or not fully tested

- This source milestone has **not** been compiled as a full Android Gradle build or tested on a physical phone in this workspace.
- MP4 export is device-codec dependent, and its hardware encoder path has not been exercised on a real device here. MP4 is currently silent; the attached audio track is not muxed into the video.
- Audio has no trim, offset, waveform, or frame-synchronization editor yet.
- GIF uses a 256-colour palette and centisecond frame timing, so gradients and some FPS values may lose precision.
- Stylus tilt/orientation and true per-point variable-width pressure brushes are not implemented yet.
- Multi-touch viewport pan/zoom, raster image import, SVG import/export, PNG transparency toggle, fill bucket, selection/lasso, shape tools, blur/smudge tools, layer groups, clipping and blend modes remain future work.
- The Asset Library currently stores vector paths; raster image assets and full animated symbol clips are not implemented.
- The editor shading preview uses a soft translucent edge approximation. The offline renderer applies a blur mask to exported soft strokes.

## Build requirements

- Android Studio with support for Android Gradle Plugin 9.1.1.
- JDK 17.
- Android SDK Platform 37 and Build-Tools 36.0.0.
- Internet access for the initial Gradle plugin and Maven dependency download.

The project uses AGP 9.1.1, Gradle 9.3.1, Kotlin Compose compiler plugin 2.2.10, and Compose BOM 2026.09.00.

## Open and build

1. Extract the ZIP archive.
2. Open the `AniMotionStudio` folder in Android Studio (the folder containing `settings.gradle.kts`).
3. Allow Gradle Sync to complete.
4. Install Android SDK Platform 37 and Build-Tools 36.0.0 from SDK Manager if requested.
5. Run the `app` configuration on an Android 8.0+ device or emulator.
6. To create a debug APK, select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The debug APK path is:

`app/build/outputs/apk/debug/app-debug.apk`

Command-line build:

- Windows: `gradlew.bat :app:assembleDebug`
- macOS/Linux: `./gradlew :app:assembleDebug`

A GitHub Actions workflow is included at `.github/workflows/android-build.yml`. Push the project to a GitHub repository and run the **Build AniMotion Studio APK** workflow to build and upload the debug APK artifact.

## Project format

The `.animotion` file is UTF-8 JSON, currently version 4. It stores canvas dimensions, FPS, frames, stable raster/vector layers, strokes (points, pressure, opacity and softness), vector anchors and Bezier handles, camera keyframes, object-transform keyframes, reusable vector assets and the selected audio URI. Versions 1–3 are supported on import.

## Package details

- Application ID: `com.animotionstudio`
- Minimum Android: 8.0 (API 26)
- Compile SDK: 37
- Target SDK: 36
- Version: 0.4.1

## Validation performed in this workspace

- Core project model and vector geometry compiled with Kotlin 1.9.0; smoke checks for layer identity, camera interpolation, object tweening and Bezier anchor edits passed.
- ProjectStore and AssetLibraryStore type-checked with an Android AtomicFile API stub.
- GIF frame-delay rounding was corrected for rates such as 24/30/60 FPS.
- Project JSON code type-checked against a minimal `org.json` compile stub.
- Export renderer/exporter and MP4/GIF code type-checked against minimal Android API stubs.
- GIF LZW output was decoded with Pillow, including a 200,000-pixel test pattern; the decoded indices matched the original test input.
- AndroidManifest XML parsed successfully.
- The full Compose UI and Android Gradle build were not compiled here. This workspace has no Android SDK/`android.jar`, no installed Gradle distribution, and cannot resolve `services.gradle.org` due to network/DNS restrictions. Therefore no installable APK or real-device test is included in this delivery.
