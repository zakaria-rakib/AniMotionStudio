# AniMotion Studio — development status

## Current source milestone: v0.4.1

### Phase 1 — Raster animation MVP

- Home screen, project creation/open/continue.
- Brush, eraser, raster layers.
- Frame-by-frame timeline, onion skin, FPS playback.
- Undo/redo and editable project saving.

### Phase 2 — Vector engine

- Editable vector paths, Bezier anchors/handles and direct anchor editing.
- Smooth/corner point conversion and vector transforms.
- Mixed raster/vector layer model and project format v2 compatibility.

### Phase 3 — Camera, assets and tweening

- Camera keyframes and interpolated camera preview.
- Vector object transform keyframes and tween rendering.
- Local reusable vector Asset Library.
- Stable layer identities across frames; layer add/delete/reorder/visibility/lock/opacity are timeline-wide.
- Project import supports versions 1–3 and migrates layer IDs to stable identities.

### Phase 4 — Shading, audio and render exports

- Shadow/Light tools with per-stroke opacity and softness.
- Stylus pressure samples stored; editor and offline renderer currently use average pressure for width.
- Attach audio from SAF; audio loops during editor playback and stops on pause.
- PNG sequence ZIP exporter using offline frame renderer.
- GIF89a exporter with 3-3-2 palette and tested LZW encoder.
- H.264 MP4 exporter using MediaCodec/MediaMuxer, requiring supported YUV420 encoder input. MP4 currently has no audio mix.

## Validation performed

- Core model and geometry compiled with Kotlin 1.9.0; model smoke checks passed for stable layer IDs, camera interpolation, object tweening and vector anchor edits.
- Project and asset persistence sources type-checked with Android AtomicFile stubs.
- Exporter/renderer sources type-checked with minimal Android API stubs; MP4 temporary cache files are now cleaned on failed exports too.
- ProjectJson type-checked with a minimal org.json compile stub.
- Frame renderer, PNG/GIF/MP4 exporter sources type-checked with minimal Android API stubs.
- GIF LZW output decoded using Pillow with both short patterns and a 200,000-pixel pseudorandom stream; test pixels matched.
- AndroidManifest XML parsed successfully.
- Static Kotlin parsing of EditorScreen found no syntax diagnostics, but the Compose UI has not been compiled against the full AndroidX dependency graph.

## Known limitations and build blocker

- No Android SDK/`android.jar` or Gradle distribution is installed in this workspace.
- DNS/network access to `services.gradle.org` is unavailable; Gradle cannot bootstrap dependencies.
- Consequently the full Android Gradle build, APK generation and device testing have not been completed here.
- MP4 device codec support is variable and has not been tested on a physical Android device. MP4 export is silent.
- Audio has no trim/sync UI and is not muxed into MP4.
- GIF uses a fixed 256-colour 3-3-2 palette.
- Stylus tilt and per-point variable-width rendering are pending; tilt is not implemented.
- Multi-touch pan/zoom, raster asset library, animated symbol clips, SVG import/export, fill/shape/selection tools, layer groups and blend modes remain future work.
